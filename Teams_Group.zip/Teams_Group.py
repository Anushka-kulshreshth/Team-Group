import random
country=['Arsenal','Astana','Atletico','BATE','CSKA Moskva','Dinamo Zagreb','Dynamo Kyiv','Galatasaray','Gent','Leverkusen','Lyon','M.Tel-Aviv','Malmo','Man.City','Man.United','Monchengladbach','Olymapiacos','Porto','Real Madrid','Roma','Sevilla','Shakhtar Donetsk','Valencia','Wolfsburg']
domestic=['Paris','PSV','Benfica','Juventus','Barcelona','Bayern','Chelsea','Zenit']
n_Group =['Group A','Group B','Group C','Group D','Group E','Group F','Group G','Group H']

for i in range(0,len(n_Group),int(len(n_Group)/2)):
    if i == 0:
        g_num = int(len(n_Group)/2)
    if i == 4:
        g_num = int(len(n_Group))

    for g1 in range(i,g_num):
        print("{:<50}".format(n_Group[g1]),end='')
    print('')

    for _ in range(i,g_num):
        rand_domestic = random.choice(domestic)
        print("{:<50}".format(rand_domestic),end='')
        domestic.remove(rand_domestic)

    for _ in range(0,3):
        print('')
        for _ in range(i,g_num):
            rand_country = random.choice(country)
            print("{:<50}".format(rand_country),end='')
            country.remove(rand_country)
    print('')
    print('')

